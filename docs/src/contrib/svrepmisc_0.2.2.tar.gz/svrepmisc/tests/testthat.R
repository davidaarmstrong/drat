library(testthat)
library(svrepmisc)

test_check("svrepmisc")
